export default interface Account {
    name: string;
    surname: string;
    lastname: string;
    joinedAt: string;
    profileUrl: string;
    chatId: string;
}