export default interface AccountDetails {
    uid: string;
    name: string;
    surname:string;
    lastName:string;
    userName:string;
    email:string;
    urlImage:string;
    role:string;
}