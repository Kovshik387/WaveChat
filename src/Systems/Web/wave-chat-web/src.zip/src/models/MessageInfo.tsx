export type MessageInfo = {
    content: string,
    sendDate: Date,
    uid: string,
    uidUser: string,
    name: string,
    uidChannel: string
}